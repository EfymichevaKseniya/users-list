import React from 'react';
import './container.scss';

export function Container() {
  return (
    <div className="container">
    </div>
  )
}
