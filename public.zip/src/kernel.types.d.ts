type Id = number | string;
type Color = 'normal' | 'disable' | 'active' | 'transparent';
